/*
 * Copyright(c) 2012-2021 Intel Corporation
 * Copyright(c) 2024 Huawei Technologies
 * Copyright(c) 2026 Unvertical
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __OCF_DEF_PRIV_H__
#define __OCF_DEF_PRIV_H__

#include "ocf/ocf.h"
#include "ocf_env.h"

#define SECTOR_SHIFT 9
#define SECTOR_SIZE (1 << SECTOR_SHIFT)

#define BYTES_TO_PAGES(x)	((((uint64_t)x) + (PAGE_SIZE - 1)) / PAGE_SIZE)
#define PAGES_TO_BYTES(x)	(((uint64_t)x) * PAGE_SIZE)

#ifdef OCF_BLOCK_SIZE_4K
#define OCF_BLOCK_SHIFT 12
#else
#define OCF_BLOCK_SHIFT SECTOR_SHIFT
#endif

#define OCF_BLOCK_SIZE (1 << OCF_BLOCK_SHIFT)
#define BYTES_TO_BLOCKS(x) \
		(((uint64_t)(x) + (OCF_BLOCK_SIZE - 1)) >> OCF_BLOCK_SHIFT)
#define BLOCKS_TO_BYTES(x) ((uint64_t)(x) << OCF_BLOCK_SHIFT)
#define BYTES_TO_BLOCKS_ROUND_DOWN(x) ((x) >> OCF_BLOCK_SHIFT)

#define OCF_DIV_ROUND_UP_STATIC(n, d) \
	(((n) + (d) - 1) / (d))

#define OCF_DIV_ROUND_UP(x, y)			\
	({					\
		__typeof__ (x) __x = (x);	\
		__typeof__ (y) __y = (y);	\
		(__x + __y - 1) / __y;		\
	})

#define OCF_MAX(x,y)				\
	({					\
		__typeof__ (x) __x = (x);	\
		__typeof__ (y) __y = (y);	\
		__x > __y ? __x : __y;		\
	})

#define OCF_MIN(x,y)				\
	({					\
		__typeof__ (x) __x = (x);	\
		__typeof__ (y) __y = (y);	\
		__x < __y ? __x : __y;		\
	})

#define METADATA_VERSION() ((OCF_VERSION_MAIN << 16) + \
		(OCF_VERSION_MAJOR << 8) + OCF_VERSION_MINOR)

/* call conditional reschedule every 'iterations' calls */
#define OCF_COND_RESCHED(cnt, iterations) \
	if (unlikely(++(cnt) == (iterations))) { \
		env_cond_resched(); \
		(cnt) = 0; \
	}

/* call conditional reschedule with default interval */
#define OCF_COND_RESCHED_DEFAULT(cnt) OCF_COND_RESCHED(cnt, 1000000)

static inline unsigned long long
ocf_rotate_right(unsigned long long bits, unsigned shift, unsigned width)
{
	return ((bits >> shift) | (bits << (width - shift))) &
		((1ULL << width) - 1);
}

struct ocf_request;

typedef void (*ocf_req_end_t)(struct ocf_request *req, int error);

#endif
