/*
 * Copyright(c) 2012-2021 Intel Corporation
 * Copyright(c) 2023-2025 Huawei Technologies
 * Copyright(c) 2026 Unvertical
 * SPDX-License-Identifier: BSD-3-Clause
 */


#ifndef __OCF_CACHE_H__
#define __OCF_CACHE_H__

/**
 * @file
 * @brief OCF cache API
 */

#include "ocf_volume.h"
#include "ocf_ctx.h"
#include "ocf_def.h"
#include "ocf_stats.h"

/**
 * @brief Cache info: configuration, status
 */
struct ocf_cache_info {
	bool attached;
		/*!< True if caching cache is attached to cache */

	uint8_t volume_type;
		/*!< Cache volume type */

	uint8_t state;
		/*!< Cache state (running/flushing/stopping etc...) */

	uint32_t size;
		/*!< Actual cache size (in cache lines) */

	/* Statistics of inactive cores */
	struct {
		struct ocf_stat occupancy;
			/*!< Cache occupancy (in cache lines) */

		struct ocf_stat clean;
			/*!< Clean blocks within cache (in cache lines) */

		struct ocf_stat dirty;
			/*!< Dirty blocks within cache (in cache lines) */
	} inactive;

	uint32_t occupancy;
		/*!< Actual cache occupancy (in cache lines) */

	uint32_t dirty;
		/*!< Dirty blocks within cache (in cache lines) */

	uint64_t dirty_for;
		/*!< How long there are dirty cache lines (in seconds) */

	uint32_t dirty_initial;
		/*!< Dirty blocks within cache that where there when switching
		 * out of WB mode
		 */

	ocf_cache_mode_t cache_mode;
		/*!< Current cache mode */

	/* Statistics of fallback Pass Through */
	struct {
		int error_counter;
			/*!< How many requests to cache failed because of IO error */

		bool status;
			/*!< Current cache mode is PT,
			  set as a result of reaching IO error threshold */
	} fallback_pt;

	ocf_cleaning_t cleaning_policy;
		/*!< Cleaning policy selected */

	ocf_promotion_t promotion_policy;
		/*!< Promotion policy selected */

	ocf_cache_line_size_t cache_line_size;
		/*!< Cache line size in KiB */

	uint32_t flushed;
		/*!< Number of block flushed in ongoing flush operation */

	uint32_t core_count;
		/*!< Number of core devices associated with this cache */

	uint64_t metadata_footprint;
		/*!< Metadata memory footprint (in bytes) */

	uint32_t metadata_end_offset;
		/*!< LBA offset where metadata ends (in 4KiB blocks) */

	bool standby_detached;
		/*!< true if cache volume detached in standby mode */
};

/**
 * @brief Obtain volume from cache
 *
 * @param[in] cache Cache object
 *
 * @retval Volume, NULL if dettached.
 */
ocf_volume_t ocf_cache_get_volume(ocf_cache_t cache);

/**
 * @brief Obtain front volume from cache
 *
 * @param[in] cache Cache object
 *
 * @retval Volume, NULL if dettached.
 */
ocf_volume_t ocf_cache_get_front_volume(ocf_cache_t cache);

/**
 * @brief Get name of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Cache name
 */
const char *ocf_cache_get_name(ocf_cache_t cache);

/**
 * @brief Check is cache in incomplete state
 *
 * @param[in] cache Cache object
 *
 * @retval 1 Cache is in incomplete state
 * @retval 0 Cache is in complete state
 */
bool ocf_cache_is_incomplete(ocf_cache_t cache);

/**
 * @brief Check if caching device is attached
 *
 * @param[in] cache Cache object
 *
 * @retval 1 Caching device is attached
 * @retval 0 Caching device is detached
 */
bool ocf_cache_is_device_attached(ocf_cache_t cache);

/**
 * @brief Check if cache object is running
 *
 * @param[in] cache Cache object
 *
 * @retval 1 Caching device is running
 * @retval 0 Caching device is not running
 */
bool ocf_cache_is_running(ocf_cache_t cache);

/**
 * @brief Check if cache is detached
 *
 * @param[in] cache Cache
 *
 * @retval 1 Caching device is detached
 * @retval 0 Caching device is not detached
 */
bool ocf_cache_is_detached(ocf_cache_t cache);

/**
 * @brief Check if cache object is standby
 *
 * @param[in] cache Cache object
 *
 * @retval 1 Caching device is in standby state
 * @retval 0 Caching device is not in standby state
 */
bool ocf_cache_is_standby(ocf_cache_t cache);

/**
 * @brief Get cache mode of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Cache mode
 */
ocf_cache_mode_t ocf_cache_get_mode(ocf_cache_t cache);

/**
 * @brief Get cache line size of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Cache line size
 */
ocf_cache_line_size_t ocf_cache_get_line_size(ocf_cache_t cache);

/**
 * @brief Get number of cache lines of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Number of cache lines
 */
ocf_cache_line_t ocf_cache_get_line_count(ocf_cache_t cache);

/**
 * @brief Convert bytes to cache lines
 *
 * @param[in] cache Cache object
 * @param[in] bytes Number of bytes
 *
 * @retval Cache lines count
 */
uint64_t ocf_cache_bytes_2_lines(ocf_cache_t cache, uint64_t bytes);

/**
 * @brief Get core count of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Core count
 */
uint32_t ocf_cache_get_core_count(ocf_cache_t cache);

/**
 * @brief Get inactive (detached or loaded from metadata) core count of
 * given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval Core inactive count
 */
uint32_t ocf_cache_get_core_inactive_count(ocf_cache_t cache);

/**
 * @brief Get cache mode of given cache object
 *
 * @param[in] cache Cache object
 * @param[out] info Cache info structure
 *
 * @retval 0 Success
 * @retval Non-zero Fail
 */
int ocf_cache_get_info(ocf_cache_t cache, struct ocf_cache_info *info);

/**
 * @brief Get UUID of volume associated with cache
 *
 * @param[in] cache Cache object
 *
 * @retval Volume UUID, NULL if detached.
 */
const struct ocf_volume_uuid *ocf_cache_get_uuid(ocf_cache_t cache);

/**
 * @brief Get OCF context of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval OCF context
 */
ocf_ctx_t ocf_cache_get_ctx(ocf_cache_t cache);

/**
 * @brief Get OCF cleaner of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval OCF cleaner, NULL if cache is in standby mode,
 * cache device is not attached (cleaner not initialized)
 * or cleaner is disabled
 */
ocf_cleaner_t ocf_cache_get_cleaner(ocf_cache_t cache);

/**
 * @brief Get volume type id of given cache object
 *
 * @param[in] cache Cache object
 *
 * @retval volume type id, -1 if device detached
 */
uint8_t ocf_cache_get_type_id(ocf_cache_t cache);

/**
 * @brief Set cache private data
 *
 * @param[in] cache Cache object
 * @param[in] priv Private data
 */
void ocf_cache_set_priv(ocf_cache_t cache, void *priv);

/**
 * @brief Get cache private data
 *
 * @param[in] cache Cache object
 *
 * @retval Private data
 */
void *ocf_cache_get_priv(ocf_cache_t cache);

/**
 * @brief Enable or disable skipping of core flushes (runtime only)
 *
 * When enabled, a flush is not forwarded to a core if no write or discard
 * reached that core since its last successful flush. Never persisted: off
 * after every cache start or load.
 *
 * @param[in] cache Cache object
 * @param[in] enabled New state
 */
void ocf_cache_set_flush_skip(ocf_cache_t cache, bool enabled);

/**
 * @brief Get core flush skipping state and counters (runtime only)
 *
 * @param[in] cache Cache object
 * @param[out] enabled Switch state (optional)
 * @param[out] forwarded Flushes forwarded to a core since cache start
 *	(optional)
 * @param[out] skipped Flushes not forwarded to a core (optional)
 */
void ocf_cache_get_flush_skip(ocf_cache_t cache, bool *enabled,
		uint64_t *forwarded, uint64_t *skipped);

#endif /* __OCF_CACHE_H__ */
